/*
 * Copyright 2025 Astryxion
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package ironfurnaces.util;

import net.minecraft.core.Direction;


public class DirectionUtil {

    public static int getId(Direction dir) {
        if (dir == Direction.DOWN) {
            return 0;
        } else if (dir == Direction.UP) {
            return 1;
        } else if (dir == Direction.NORTH) {
            return 2;
        } else if (dir == Direction.SOUTH) {
            return 3;
        } else if (dir == Direction.WEST) {
            return 4;
        } else if (dir == Direction.EAST) {
            return 5;
        }

        return 0;
    }

    public static Direction fromId(int id) {
        switch (id) {
            case 0:
                return Direction.DOWN;
            case 1:
                return Direction.UP;
            case 2:
                return Direction.NORTH;
            case 3:
                return Direction.SOUTH;
            case 4:
                return Direction.WEST;
            case 5:
                return Direction.EAST;
            default:
                return Direction.DOWN;
        }
    }

}
